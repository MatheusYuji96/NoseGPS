export { SectionHeading } from './SectionHeading'
